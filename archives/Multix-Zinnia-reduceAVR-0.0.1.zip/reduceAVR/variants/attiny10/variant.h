/* variant.h
 *
 * ATtiny10 6 pin Family
 */
#pragma once
#include <avr/interrupt.h>
#include <avr/sleep.h>
#include <avr/pgmspace.h>
#include <util/atomic.h>
#include <variant_io.h>
#include <api/CLKCTRL_reduceAVR.h>

#define AVR_REDUCEAVR 1
#define AVR_TPI       1
#define AVR_TPI6      1

//// Pin name to PORT configuration
////   bit[756] PORTA-G index position
////   bit[4]   1 (+16) (A=16,B=48,C=80,D=112,E=144,F=176,G=208)
////   bit[4]   0
////   bit[210] PIN0-7 bit position (0-7)

/* GPIO x4 (other VDD,GND) */

#define PIN_PB0 224
#define PIN_PB1 225
#define PIN_PB2 226
#define PIN_PB3 227

#define NOT_A_PIN   255
#define PIN_RST     PIN_PB3

#ifndef LED_BUILTIN
#define LED_BUILTIN PIN_PB1   /* PWM Channel OC0B Pin */
#endif
/* #define LED_BUILTIN_INVERT */ /* implementation dependent */

#ifdef __cplusplus
extern "C" {
#endif

inline void initVariant (void) {
  PORTCTRL_DIDIS = ~0;  /* Digital Input Disable all pin */
  _CLKCTRL_SETUP();
}

#ifdef __cplusplus
} // extern "C"
#endif

// end of code
