/* peripheral.h
 *
 * ATtiny10 6 pin Family
 */
#pragma once

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} // extern "C"
#endif

// end of code
