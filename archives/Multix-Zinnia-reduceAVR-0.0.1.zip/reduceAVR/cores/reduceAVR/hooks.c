/**
 * @file hooks.c
 * @author Kazuhiko Sato (@askn37)
 * @brief __empty and yield stab
 * @version 0.1
 * @date 2022-09-21
 *
 * @copyright Copyright (c) 2022
 *
 */
extern void yield (void);
extern void loop (void);
extern void setup (void);

__attribute__ ((weak)) void yield (void) {}
__attribute__ ((weak)) void loop (void) {}
__attribute__ ((weak)) void setup (void) {}

// end of code
