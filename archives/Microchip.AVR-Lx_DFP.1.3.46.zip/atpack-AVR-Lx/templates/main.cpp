/*
 * $projectname$.cpp
 *
 * Created: $date$
 * Author : $user$
 */

#include <stdbool.h>
#include <avr/io.h>


int main(void)
{
    /* Replace with your application code */
    while (true)
    {
    }
}

