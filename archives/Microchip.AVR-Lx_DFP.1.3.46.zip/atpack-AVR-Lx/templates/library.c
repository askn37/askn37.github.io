/*
 * $projectname$.c
 *
 * Created: $date$
 * Author : $user$
 */

#include <avr/io.h>

int myfunc(void);

/* Replace with your library code */
int myfunc(void)
{
    return 0;
}

