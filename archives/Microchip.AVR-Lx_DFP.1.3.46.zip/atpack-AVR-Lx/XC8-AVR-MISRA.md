# MISRA-C:2023 Compliance Deviations List

## Deviation ID: MFWCG-40

- **Rule 5.5**: Identifiers shall be distinct from macro names.
- **Use case**: Identifiers corresponding to register names.

  Example:

  ```C
  /* User Row */
  typedef struct USERROW_struct
  {
      register8_t USERROW[64];  /* User Row */
  } USERROW_t;

  #define USERROW           (*(USERROW_t *) 0x1080) /* User Row */
  ```

- **Reason**: Access to hardware.

  The macros expand into the same identifiers, which allow users to detect
  for the presence of specific registers during preprocessing.

- **Scope**: Device headers for AVRDx, AVREx, AVRLx and AVRSx family
  (`<device-name>.h`).
