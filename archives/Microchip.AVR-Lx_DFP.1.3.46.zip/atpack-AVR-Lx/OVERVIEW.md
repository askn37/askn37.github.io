# Overview

The Microchip AVR-Lx Series Device Family Pack (DFP) is a [CMSIS-Pack](https://open-cmsis-pack.github.io/Open-CMSIS-Pack-Spec/main/html/index.html) that:

- Enables compatible tools with device support.
- Contains support files for the [MPLAB XC8 Compiler](https://www.microchip.com/en-us/tools-resources/develop/mplab-xc-compilers/xc8).
- Contains support files for the GCC compiler.

## Devices

### [AVR16LA14](https://www.microchip.com/en-us/product/avr16la14)

The AVR16LA14 is part of the low-voltage AVR LA microcontroller family featuring the AVR&#xAE; CPU with a hardware multiplier, running up to 20 MHz, and with 16 KB Flash, 2 KB SRAM, and 512B of EEPROM in 14-pin packages. Supporting a supply voltage range from 1.62V all the way up to 5.5V, the AVR16LA14 microcontroller is suitable for both low- and standard voltage environments.The Peripheral Touch Controller (PTC) is offering enhanced noise suppression capabilities, ensuring reliable touch sensing even in challenging conditions. Additionally, the family boasts a high pin-to-touch channel ratio having touch capabilities on almost every pin, enabling efficient utilization of available pins for touch functionality and maximizing design versatility.The AVR LA family is available in 32KB and 16KB Flash memory and in 14-, 20-, 28- and 32-pins packages.Functional Safety This product is suitable for safety-critical applications that target home appliances (IEC 60730), automotive (ISO 26262) and industrial (IEC 61508) products. We have important documentation and tools available to aid developers of safety applications—refer to the product feature list for links to the specific safety collateral. TÜV SÜD-certified MPLAB&#xAE; X Integrated Development Environment (IDE) tools, such as the MPLAB XC8 Functional Safety Compiler, are also available for this product.

### [AVR16LA20](https://www.microchip.com/en-us/product/avr16la20)

The AVR16LA20 is part of the low-voltage AVR LA microcontroller family featuring the AVR&#xAE; CPU with a hardware multiplier, running up to 20 MHz, and with 16 KB Flash, 2 KB SRAM, and 512B of EEPROM in 20-pin packages. Supporting a supply voltage range from 1.62V all the way up to 5.5V, the AVR16LA20 microcontroller is suitable for both low- and standard voltage environments.The Peripheral Touch Controller (PTC) is offering enhanced noise suppression capabilities, ensuring reliable touch sensing even in challenging conditions. Additionally, the family boasts a high pin-to-touch channel ratio having touch capabilities on almost every pin, enabling efficient utilization of available pins for touch functionality and maximizing design versatility.The AVR LA family is available in 32KB and 16KB Flash memory and in 14-, 20-, 28- and 32-pins packages.Functional Safety This product is suitable for safety-critical applications that target home appliances (IEC 60730), automotive (ISO 26262) and industrial (IEC 61508) products. We have important documentation and tools available to aid developers of safety applications—refer to the product feature list for links to the specific safety collateral. TÜV SÜD-certified MPLAB&#xAE; X Integrated Development Environment (IDE) tools, such as the MPLAB XC8 Functional Safety Compiler, are also available for this product.

### [AVR16LA28](https://www.microchip.com/en-us/product/avr16la28)

The AVR16LA28 is part of the low-voltage AVR LA microcontroller family featuring the AVR&#xAE; CPU with a hardware multiplier, running up to 20 MHz, and with 16 KB Flash, 2 KB SRAM, and 512B of EEPROM in 28-pin packages. Supporting a supply voltage range from 1.62V all the way up to 5.5V, the AVR16LA28 microcontroller is suitable for both low- and standard voltage environments.The Peripheral Touch Controller (PTC) is offering enhanced noise suppression capabilities, ensuring reliable touch sensing even in challenging conditions. Additionally, the family boasts a high pin-to-touch channel ratio having touch capabilities on almost every pin, enabling efficient utilization of available pins for touch functionality and maximizing design versatility.The AVR LA family is available in 32KB and 16KB Flash memory and in 14-, 20-, 28- and 32-pins packages.Functional Safety This product is suitable for safety-critical applications that target home appliances (IEC 60730), automotive (ISO 26262) and industrial (IEC 61508) products. We have important documentation and tools available to aid developers of safety applications—refer to the product feature list for links to the specific safety collateral. TÜV SÜD-certified MPLAB&#xAE; X Integrated Development Environment (IDE) tools, such as the MPLAB XC8 Functional Safety Compiler, are also available for this product.

### [AVR16LA32](https://www.microchip.com/en-us/product/avr16la32)

The AVR16LA32 is part of the low-voltage AVR LA microcontroller family featuring the AVR&#xAE; CPU with a hardware multiplier, running up to 20 MHz, and with 16 KB Flash, 2 KB SRAM, and 512B of EEPROM in 32-pin packages. Supporting a supply voltage range from 1.62V all the way up to 5.5V, the AVR16LA32 microcontroller is suitable for both low- and standard voltage environments.The Peripheral Touch Controller (PTC) is offering enhanced noise suppression capabilities, ensuring reliable touch sensing even in challenging conditions. Additionally, the family boasts a high pin-to-touch channel ratio having touch capabilities on almost every pin, enabling efficient utilization of available pins for touch functionality and maximizing design versatility.The AVR LA family is available in 32KB and 16KB Flash memory and in 14-, 20-, 28- and 32-pins packages.Functional Safety This product is suitable for safety-critical applications that target home appliances (IEC 60730), automotive (ISO 26262) and industrial (IEC 61508) products. We have important documentation and tools available to aid developers of safety applications—refer to the product feature list for links to the specific safety collateral. TÜV SÜD-certified MPLAB&#xAE; X Integrated Development Environment (IDE) tools, such as the MPLAB XC8 Functional Safety Compiler, are also available for this product.

### [AVR32LA14](https://www.microchip.com/en-us/product/avr32la14)

The AVR32LA14 is part of the low-voltage AVR LA microcontroller family featuring the AVR&#xAE; CPU with a hardware multiplier, running up to 20 MHz, and with 32 KB Flash, 2 KB SRAM, and 512B of EEPROM in 14-pin packages. Supporting a supply voltage range from 1.62V all the way up to 5.5V, the AVR32LA14 microcontroller is suitable for both low- and standard voltage environments.The Peripheral Touch Controller (PTC) is offering enhanced noise suppression capabilities, ensuring reliable touch sensing even in challenging conditions. Additionally, the family boasts a high pin-to-touch channel ratio having touch capabilities on almost every pin, enabling efficient utilization of available pins for touch functionality and maximizing design versatility.The AVR LA family is available in 32KB and 16KB Flash memory and in 14-, 20-, 28- and 32-pins packages.Functional Safety This product is suitable for safety-critical applications that target home appliances (IEC 60730), automotive (ISO 26262) and industrial (IEC 61508) products. We have important documentation and tools available to aid developers of safety applications—refer to the product feature list for links to the specific safety collateral. TÜV SÜD-certified MPLAB&#xAE; X Integrated Development Environment (IDE) tools, such as the MPLAB XC8 Functional Safety Compiler, are also available for this product.

### [AVR32LA20](https://www.microchip.com/en-us/product/avr32la20)

The AVR32LA20 is part of the low-voltage AVR LA microcontroller family featuring the AVR&#xAE; CPU with a hardware multiplier, running up to 20 MHz, and with 32 KB Flash, 2 KB SRAM, and 512B of EEPROM in 20-pin packages. Supporting a supply voltage range from 1.62V all the way up to 5.5V, the AVR32LA20 microcontroller is suitable for both low- and standard voltage environments.The Peripheral Touch Controller (PTC) is offering enhanced noise suppression capabilities, ensuring reliable touch sensing even in challenging conditions. Additionally, the family boasts a high pin-to-touch channel ratio having touch capabilities on almost every pin, enabling efficient utilization of available pins for touch functionality and maximizing design versatility.The AVR LA family is available in 32KB and 16KB Flash memory and in 14-, 20-, 28- and 32-pins packages.Functional Safety This product is suitable for safety-critical applications that target home appliances (IEC 60730), automotive (ISO 26262) and industrial (IEC 61508) products. We have important documentation and tools available to aid developers of safety applications—refer to the product feature list for links to the specific safety collateral. TÜV SÜD-certified MPLAB&#xAE; X Integrated Development Environment (IDE) tools, such as the MPLAB XC8 Functional Safety Compiler, are also available for this product.

### [AVR32LA28](https://www.microchip.com/en-us/product/avr32la28)

The AVR32LA28 is part of the low-voltage AVR LA microcontroller family featuring the AVR&#xAE; CPU with a hardware multiplier, running up to 20 MHz, and with 32 KB Flash, 2 KB SRAM, and 512B of EEPROM in 28-pin packages. Supporting a supply voltage range from 1.62V all the way up to 5.5V, the AVR32LA28 microcontroller is suitable for both low- and standard voltage environments.The Peripheral Touch Controller (PTC) is offering enhanced noise suppression capabilities, ensuring reliable touch sensing even in challenging conditions. Additionally, the family boasts a high pin-to-touch channel ratio having touch capabilities on almost every pin, enabling efficient utilization of available pins for touch functionality and maximizing design versatility.The AVR LA family is available in 32KB and 16KB Flash memory and in 14-, 20-, 28- and 32-pins packages.Functional Safety This product is suitable for safety-critical applications that target home appliances (IEC 60730), automotive (ISO 26262) and industrial (IEC 61508) products. We have important documentation and tools available to aid developers of safety applications—refer to the product feature list for links to the specific safety collateral. TÜV SÜD-certified MPLAB&#xAE; X Integrated Development Environment (IDE) tools, such as the MPLAB XC8 Functional Safety Compiler, are also available for this product.

### [AVR32LA32](https://www.microchip.com/en-us/product/avr32la32)

The AVR32LA32 is part of the low-voltage AVR LA microcontroller family featuring the AVR&#xAE; CPU with a hardware multiplier, running up to 20 MHz, and with 32 KB Flash, 2 KB SRAM, and 512B of EEPROM in 32-pin packages. Supporting a supply voltage range from 1.62V all the way up to 5.5V, the AVR32LA32 microcontroller is suitable for both low- and standard voltage environments.The Peripheral Touch Controller (PTC) is offering enhanced noise suppression capabilities, ensuring reliable touch sensing even in challenging conditions. Additionally, the family boasts a high pin-to-touch channel ratio having touch capabilities on almost every pin, enabling efficient utilization of available pins for touch functionality and maximizing design versatility.The AVR LA family is available in 32KB and 16KB Flash memory and in 14-, 20-, 28- and 32-pins packages.Functional Safety This product is suitable for safety-critical applications that target home appliances (IEC 60730), automotive (ISO 26262) and industrial (IEC 61508) products. We have important documentation and tools available to aid developers of safety applications—refer to the product feature list for links to the specific safety collateral. TÜV SÜD-certified MPLAB&#xAE; X Integrated Development Environment (IDE) tools, such as the MPLAB XC8 Functional Safety Compiler, are also available for this product.

## MISRA-C:2023 Compliance Deviations List

### Deviation ID: MFWCG-40

- **Rule 5.5**: Identifiers shall be distinct from macro names.
- **Use case**: Identifiers corresponding to register names.

  Example:

  ```C
  /* User Row */
  typedef struct USERROW_struct
  {
      register8_t USERROW[64];  /* User Row */
  } USERROW_t;

  #define USERROW           (*(USERROW_t *) 0x1080) /* User Row */
  ```

- **Reason**: Access to hardware.

  The macros expand into the same identifiers, which allow users to detect
  for the presence of specific registers during preprocessing.

- **Scope**: Device headers for AVRDx, AVREx, AVRLx and AVRSx family
  (`<device-name>.h`).


## Support

For support questions, contact Microchip Support through [https://www.microchip.com/en-us/support](https://www.microchip.com/en-us/support).
