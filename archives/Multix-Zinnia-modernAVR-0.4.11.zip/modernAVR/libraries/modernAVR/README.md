# Multix Zinnia Product SDK [Macro/Micro API libraries and samples]

__Multix Zinnia Product SDK__
の共通サブモジュール。

AVR-GCC / AVR-LIBC 専用。__Arduino互換API用ではない。__

## 対象AVR

- megaAVR世代
  - megaAVR-0系統
  - tinyAVR-0/1/2系統
- modernAVR世代
  - AVR-Dx系統
  - AVR-Ex系統
  - AVR Lx系統
  - AVR Sx系統

## パス配置

このモジュールは __Arduino IDE__ の
`boards.txt/platform.txt`において
以下のパスに配置される。

```plain
{runtime.platform.path}/cores/{build.core}        <-- MacroAPI_core {includes}
{runtime.platform.path}/libraries/{build.core}    <-- このサブモジュール
{runtime.platform.path}/libraries/M5_Modules      <-- M5_Modules
{runtime.platform.path}/variants/{build.variant}  <-- ボード固有設定 {includes}
```

## 収容ライブラリ

| 名称           | 機能                                                                                                             |
| -------------- | ---------------------------------------------------------------------------------------------------------------- |
| FlashNVM.h     | [フラッシュメモリ領域自己書換支援](https://github.com/askn37/askn37.github.io/wiki/FlashNVM)                     |
| FontSets.h     | [OLED用英数フォントイメージ](https://github.com/askn37/askn37.github.io/wiki/FontSets)                           |
| GPS_RMS.h      | [簡易NMEAパーサ](https://github.com/askn37/askn37.github.io/wiki/GPS_RMC)                                        |
| OLED_*.h       | [OLEDパネル(I2C)制御支援](https://github.com/askn37/askn37.github.io/wiki/OLED_SSD1306)                          |
| ReadUART.h     | [リードバッファ付ハードウェアUSART](https://github.com/askn37/askn37.github.io/wiki/ReadUART)                    |
| SerialUSB.h    | [USB-CDC VCOM実装](https://github.com/askn37/askn37.github.io/wiki/SerialUSB) (__AVR-DU系列専用__)               |
| SoftwareUART.h | [SoftwareSerial代替](https://github.com/askn37/askn37.github.io/wiki/SoftwareUART)                               |
| TaskChanger.h  | [協調的マルチタスク支援](https://github.com/askn37/askn37.github.io/wiki/TaskChanger)                            |
| TimeoutTimer.h | [RTCによるタイムアウト制御支援](https://github.com/askn37/askn37.github.io/wiki/TimeoutTimer)と delay/millis代替 |
| UrowNVM.h      | [USERROW領域書き換え支援](https://github.com/askn37/askn37.github.io/wiki/UrowNVM)                               |
| XRTC_*.h       | [外部RTC制御支援](https://github.com/askn37/askn37.github.io/wiki/XRTC_PCF85063A)（NXP PCF85063A用）             |
| bcddatetime.h  | [BCD年月日/時分秒表現とMJD変換支援](https://github.com/askn37/askn37.github.io/wiki/bcddatetime)                 |

## 収容サンプルスケッチ

| 群                    | 種別                                 |
| --------------------- | ------------------------------------ |
| Blink variations      | 様々な Lチカ 実演                    |
| Two Wire Interfaces   | TWI / I2C操作実演                    |
| EEPROM and NVM        | 不揮発メモリ操作実演                 |
| Timer applications    | 計時器/計数器周辺機能の様々な応用    |
| UART and USART        | UART/USART実演                       |
| USB for AVR-DU series | USB周辺機能実装実演 / AVR-DU系列専用 |
| Miscellaneous         | その他の様々な実演                   |

## 更新履歴

- 0.4.11 (26/10/22)
  - (lib) USB/CDC修正

- 0.4.10 (26/09/17)
  - (core) 連携修正

- 0.4.8 (26/09/01)
  - サンプルスケッチ修正

- 0.4.6 (26/08/28)
  - [Timer applications] にサンプルスケッチ [GPIOキャプチャによる簡易ロジックアナライザー] を追加

- 0.4.4 (26/08/05)
  - __AVR32SD14/20/28/32__ に対応
  - Microchip.AVR8-atpack を`20260522` に更新

- 0.4.3 (26/07/30)
  - __AVR32LA14/20/28/32__ に対応

- 0.4.2 (26/07/12)
  - ドキュメントとスケッチの更新

- 0.4.1 (26/07/09)
  - `euboot@3.72.49`アップデート
  - *AVR DU with USB Bootloader* で実験的な自動リセット付きスケッチアップロードに対応（Arduino Leonard/Pro Micro/Every Nano と同様の挙動）

- 0.4.0 (26/07/05)
  - ドキュメント修正
  - avr8-gcc15 に関係するコード修正
  - 上位実装（modernAVR等）の更新に伴うバージョン番号の変更

- 0.2.14 (24/06/17)
  - 各ファイルの MITライセンスリンク対応
  - modernAVR: __AVR-DU系列専用__ USB周辺機能に暫定対応
    - `<SerialUSB.h>` 基本的な USB-SERIAL通信クラス
    - `<USB/USB_CDC.h>` 上記の下位実装（USB-CDC）

## 著作表示

Twitter: [@askn37](https://twitter.com/askn37) \
BlueSky Social: [@multix.jp](https://bsky.app/profile/multix.jp) \
GitHub: [https://github.com/askn37/](https://github.com/askn37/) \
Product: [https://askn37.github.io/](https://askn37.github.io/)

Copyright (c) askn (K.Sato) multix.jp \
Released under the MIT license \
[https://opensource.org/licenses/mit-license.php](https://opensource.org/licenses/mit-license.php) \
[https://www.oshwa.org/](https://www.oshwa.org/)
