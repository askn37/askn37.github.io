/**
 * @file boot_dx.c
 * @author askn (K.Sato) multix.jp
 * @brief Arduino-compatible serial bootloader for AVR_Ex/Lx
 * @version 3.73
 * @date 2026-08-01
 * @copyright Copyright (c) 2026 askn37 at github.com
 */
// MIT License : https://askn37.github.io/LICENSE.html

/***

+++ OVERVIEW +++

This bootstrap loader firmware for moderAVR is based on the ATMEL STK500
version 1 protocol and is fully compatible with Arduino bootloaders.

When the firmware boots, the RESET information flag is checked and, in the
case of a WDT or software reset, the application code (starting at 0x200)
starts executing immediately. Otherwise, if a valid STK500 version 1
command is received within the timeout period, the UART will open and he
will start NVM operations.

Builds are possible with AVR-GCC and AVR-LIBC, but other compilers are not
considered. Binary code fits within 512 bytes.

Previously, the source code was a clone of "Optiboot", but this is no longer
the case. They, as a rule, only support older generation devices. For these
reasons, the source code published here has been rewritten.

Licensing and redistribution are subject to the MIT License.

***/

#include <avr/io.h>
#include "boot_dx.h"

#ifndef UART_BASE
  #warning UART is ignored for this chip (use UART=<TxD-PortPin> instead)
#endif

#ifndef USART
/*** For an asynchronous UART, perform the following settings. ***/

/***
  All AVR_Dx Series products are reset to run on a 4 MHz internal oscillator.
  Calculating the division ratio is therefore simple.
***/
  #define BAUD_SETTING ((F_CPU * 64) / (16L * BAUD_RATE))
  #if (BAUD_SETTING < 64)
    /* max BAUD_RATE 250000 bps (4 Mhz) */
    #error Unachievable baud rate (too fast) BAUD_RATE
    #include "BUILD_STOP"
  #elif (BAUD_SETTING > 65535)
    /* min BAUD_RATE 245 bps (4 Mhz) */
    #error Unachievable baud rate (too slow) BAUD_RATE
    #include "BUILD_STOP"
  #endif
#endif /* not USART */

/***
  This section provides an auxiliary capability
  for self-modifying the flash area.

  $0000 : Started Bootloader (POR)       $C02F
  $0002 : nvm_stz function : magicnumber $95089361
  $0006 : nvm_ldz function : magicnumber $95089181
  $000A : nvm_spm function : magicnumber $950895F8
  $000E : nvm_cmd function : magicnumber $BF94E99D
  $0200 : appcode
***/

__attribute__((used))
__attribute__((naked))
__attribute__((noinline))
__attribute__((section (".vectors")))
void vector_table (void) {
  __asm__ __volatile__ (
  R"#ASM#(
    RJMP  bootload  ; $0000
    ST    Z+, R22   ; $0002 nvm_stz
    RET
    LD    R24, Z+   ; $0006 nvm_ldz
    RET
    SPM   Z+        ; $000A nvm_spm
    RET
  )#ASM#"
  );
  /* next is nvm_cmd */
}

/* The SPM snippet consists of two functions.
   One is to simply execute an SPM instruction.
   The next step is to write CMD to her NVMCTRL and check the STATUS. */

__attribute__((used))
__attribute__((noinline))
__attribute__((section (".init0")))
void nvm_cmd (uint8_t _nvm_cmd) {
  /* This function occupies 18 bytes of space. */
  _PROTECTED_WRITE_SPM(NVMCTRL_CTRLA, _nvm_cmd);
  while (NVMCTRL_STATUS & 3);
}

__attribute__((noinline))
void putch (uint8_t ch) {
  /* Put-Character will not send the character unless the buffer is empty. */
  loop_until_bit_is_set(UART_BASE.STATUS, USART_DREIF_bp);
  UART_BASE.TXDATAL = ch;
  #ifdef RS485_SINGLE
  /* drop loopback */
  pullch();
  #endif
}

__attribute__((noinline))
uint8_t pullch (void) {
  /* Pull-Character blocks if buffer is empty.
     If nothing is received, WDT will eventually work. */
  uint8_t ch, er;
  loop_until_bit_is_set(UART_BASE.STATUS, USART_RXCIF_bp);
  er = UART_BASE.RXDATAH;
  ch = UART_BASE.RXDATAL;
  /* If there are no frame errors, pet the dog. */
  if ((er & USART_FERR_bm) == 0) wdt_reset();
#ifdef LED_PORT
  LED_PORT.IN |= _BV(LED_PIN);
#endif
  return ch;
}

__attribute__((noinline))
void end_of_packet (void) {
  if (pullch() != CRC_EOP) {
    /* If the End of Packet marks do not match, the system will be reset. */
    __asm__ __volatile__ ( "RJMP vector_table" );
  }
  putch(STK_INSYNC);
}

__attribute__((naked))
__attribute__((noinline))
void drop_packet (uint8_t count) {
  /* Closes the received packet by discarding
     the indicated number of characters. */
  // do pullch(); while (--count);
  // end_of_packet();
  __asm__ __volatile__ (
  R"#ASM#(
      MOV   R22, R24
  1:  RCALL pullch
      SUBI  R22, 1
      BRNE  1b
      RJMP  end_of_packet
  )#ASM#" ::: "r22"
  );
}

#if defined(LED_BLINK) && defined(LED_PORT) && (LED_BLINK >= 2)
inline static
void blink (void) {
  /* Makes the LED blink at a different rate than normal.
     This code uses about 10 bytes of extra space. */
  uint8_t count = LED_BLINK;
  do {
    LED_PORT.IN |= _BV(LED_PIN);
    /* delay assuming 4Mhz */
    uint16_t delay = 4000000U / 150;
    do {
      if (bit_is_set(UART_BASE.STATUS, USART_RXCIF_bp)) return;
    } while (--delay);
  }
  while (--count);
}
#endif

// MARK: bootload (main) function

__attribute__((used))
__attribute__((naked))
__attribute__((noinline))
__attribute__((noreturn))
void bootload (void) {
  /* It is preferable that these variables be allocated directly to registers. */
  addr16_t address;
  addr16_t length;
  uint8_t ch;

  /* This is the first code that is executed.
     According to modernAVR specifications,
     interrupts are disabled and SP points to RAMEND. */

  /* Known-zero required by avr-libc. */
  __asm__ __volatile__ ( "CLR __zero_reg__" );

  /* Get the reset reason. The value is also copied to GPR0. */
  ch = RSTCTRL_RSTFR; /* get reset cause */
  RSTCTRL_RSTFR = ch; /* clear flags */
  GPR_GPR0 = ch;      /* Backup so user code can be referenced */

  /* If register is zero, perform software reset */
  if (ch == 0) _PROTECTED_WRITE(RSTCTRL_SWRR, 1);

  #ifdef PORSTRAP
  /* WDT reset executes user code */
  if (bit_is_set(GPR_GPR0, RSTCTRL_WDRF_bp))
  #else
  /* WDT and hardware restart causes user code to execute */
  if (ch & (RSTCTRL_WDRF_bm | RSTCTRL_BORF_bm | RSTCTRL_PORF_bm))
  #endif
  {
    __asm__ __volatile__ ( "RJMP appcode" );
  }

  /* Set LED pin as output */
#ifdef LED_PORT
  LED_PORT.DIR |= _BV(LED_PIN);
#endif

#ifdef FREQSEL
  _PROTECTED_WRITE(CLKCTRL_MCLKCTRLA, 0);         // CLKCTRL_CLKSEL_OSCHF_gc
  _PROTECTED_WRITE(CLKCTRL_OSCHFCTRLA, FREQSEL);  // CLKCTRL_FREQSEL_4M_gc
#endif

#ifdef UART_PMUX_VAL
  /* PORTMUX setting.
     Should be omitted if no alternate is set. */
  UART_PMUX_REG = UART_PMUX_VAL;
#endif

#if defined(PULLUP_RX) && !defined(RS485_SINGLE) && !defined(USART)
  /* RX pin pullup (RX is TX next GPIO).
     Normally, the TxD side is push-pull, so it is not required. */
  UART_RXCFG = PORT_PULLUPEN_bm;
#endif

/* Communication Mode Setup */
#if defined(RS485) || defined(RS485_SINGLE)
  /*** For RS485 client mode ***/
  /* This is intended solely for synchronous.
     It can also be configured for open-drain single-wire driving. */

  #if defined(RS485_INVERT)
  UART_XDIRCFG = PORT_INVEN_bm;
  #endif
  UART_TXPORT.DIR |= UART_XDIRPIN;

  UART_BASE.CTRLC = USART_CHSIZE_8BIT_gc | USART_CMODE_SYNCHRONOUS_gc;

  #if defined(RS485_SINGLE)
  UART_TXCFG = PORT_PULLUPEN_bm;
  UART_BASE.CTRLA = USART_RS485_ENABLE_gc | _BV(1) | USART_LBME_bm;
  UART_BASE.CTRLB = USART_RXEN_bm | USART_TXEN_bm | USART_ODME_bm;
  #else
  UART_BASE.CTRLA = USART_RS485_ENABLE_gc | _BV(1);
  UART_BASE.CTRLB = USART_RXEN_bm | USART_TXEN_bm;
  #endif

#elif defined(USART)
  /*** For synchronous client USART ***/
  #ifdef USART_INVERT
  UART_XCKCFG = PORT_INVEN_bm;
  #endif

  UART_BASE.CTRLC = USART_CHSIZE_8BIT_gc | USART_CMODE_SYNCHRONOUS_gc;
  UART_BASE.CTRLB = USART_RXEN_bm | USART_TXEN_bm;

#else /* UART */
  /* For standard asynchronous UART */

  /* BAUDH is zero, so if you don't need it, just write BAUDL */
  #if (BAUD_SETTING_16 < 256)
  UART_BASE.BAUDL = BAUD_SETTING;
  #else
  UART_BASE.BAUD = BAUD_SETTING;
  #endif

  /* This is the same as the default value for CTRLC, so it can be omitted. */
  // UART_BASE.CTRLC = USART_CHSIZE_8BIT_gc | USART_CMODE_ASYNCHRONOUS_gc;
  UART_BASE.CTRLB = USART_RXEN_bm | USART_TXEN_bm;

#endif  /* Communication Mode Setup */

/* At this stage, the UART only acts as a receiver. */
/* TxD pin is not configured as an output yet and remains Hi-Z. */

#if defined(LED_BLINK) && defined(LED_PORT) && (LED_BLINK >= 2)
  /* LED flashing time is not included in WDT limit. */
  blink();
#elif defined(LED_PORT)
  /* Set noinit SRAM as a flag and make the LED blink
     alternately every time the WDT restarts. */
  if (++_SFR_MEM8(RAMEND - 767) & 1) LED_PORT.IN |= _BV(LED_PIN);
#endif

  /* This probably isn't necessary since WDT isn't started yet. */
  // loop_until_bit_is_clear(WDT_STATUS, WDT_SYNCBUSY_bp);

  /* Start WDT monitoring */
  _PROTECTED_WRITE(WDT_CTRLA, WDTPERIOD);

  /*** Forever loop: exits by causing WDT reset ***/
  for (;;) {
    /* get STK Command */
    ch = pullch();
    if (ch == STK_GET_PARAMETER) {
      ch = pullch();
      end_of_packet();
      if (ch == PAR_SW_MINOR)
        ch = BOOT_MINVER;
      /* To save space, this value is not returned */
      // else if (ch == PAR_SW_MAJOR)
      //   ch = BOOT_MAJVER;
      else
        ch = BOOT_HW_VER;
      putch(ch);
    }
    else if (ch == STK_SET_DEVICE) {
      /* SET_DEVICE is ignored */
      /* drop 20bytes */
      drop_packet(20);
    }
    else if (ch == STK_SET_DEVICE_EXT) {
      /* SET_DEVICE EXT is ignored */
      /* drop 5bytes */
      drop_packet(5);
    }
    else if (ch == STK_LOAD_ADDRESS) {
      /* LOAD_ADDRESS little endian */
      address.bytes[0] = pullch();
      address.bytes[1] = pullch();
      /* byte addressed mode */
      end_of_packet();
    }
  #ifdef RAMPZ
    /***
      RAMPZ - Extended Z Pointer Register
      This register is only present on AVRs with FLASH greater than 128KiB.
      For lower-level varieties, even if you write to it, it will always
      be treated as zero and will not function.
    ***/
    else if (ch == STK_UNIVERSAL) {
    #if ENABLE_MORE_ACCURATELY
      if (pullch() == PAR_LOAD_EXT_ADDR) {
        /* get address (24bit-wide, 3bytes) */
        pullch();         /* drop ADDR1 */
        RAMPZ = pullch(); /* get the ADDR2 and put it in RAMPZ */
        drop_packet(1);   /* drop ADDR3 */
      }
      else {
        drop_packet(3);   /* drop 3bytes */
      }
    #else
      /* STK_UNIVERSAL should not be used except for PAR_LOAD_EXT_ADDR */
      pullch();           /* drop PAR_LOAD_EXT_ADDR */
      pullch();           /* drop ADDR1 */
      RAMPZ = pullch();   /* get the ADDR2 and put it in RAMPZ */
      /* This value should indicate the 17th bit of the direct address */
      drop_packet(1);     /* drop ADDR3 */
    #endif
      putch(0x00);        /* STK_UNIVERSAL response '0' */
    }
  #endif
    else if (ch == STK_PROG_PAGE) {
      /* Flash or EEPROM */
      /* Write memory block mode, length is big endian. */
      length.bytes[1] = pullch();
      length.bytes[0] = pullch();
      ch = pullch();
      uint16_t len = length.word;

      /* Any chip has at least 1KiB of SRAM,
         so buffers are reserved in fixed locations. */
      uint8_t* _buff = RAMEND - 767;
      addr16_t buff = {_buff};
      do *buff.bptr++ = pullch(); while (--len);
      buff.bptr = _buff;

      if (ch == 'F') {
        /***
          Please set the RAMPZ IO register (0x003B) correctly before calling.
          The counter is in “WORD” units.
          Out of range is initialized to 0xFF and rewritten for each page block.
          Do not add MAPPED_PROGMEM_START as you are using absolute addresses.
        ***/
        ch = length.word >> 1;
        __asm__ __volatile__ (
          R"#ASM#(
              LDI   R24, %3       ; R24 <- NVMCTRL_CMD_FLPER
              RCALL nvm_cmd       ; Change NVMCTRL command
              SPM                 ; DS(RAMPZ:Z) <- 0xFFFF dummy write
          )#ASM#"
          R"#ASM#(
              LDI   R24, %4       ; R24 <- NVMCTRL_CMD_FLWR
              RCALL nvm_cmd       ; Change NVMCTRL command
          1:  LD    R0, X+        ; R0 <- X+
              LD    R1, X+        ; R1 <- X+
              SPM   Z+            ; DS(RAMPZ:Z+) <- R1:R0
              DEC   %0            ; Decrement
              BRNE  1b            ; Branch if Not Equal
              CLR   __zero_reg__  ; R1 <- 0
          )#ASM#"
          :
          : "r" ((uint8_t)ch)    /* word length counter */
          , "z" (address.bptr)   /* Z <- to flash.ptr   */
          , "x" (buff.bptr)      /* X <- from sram.ptr  */
          , "I" ((uint8_t)NVMCTRL_CMD_FLPER_gc)
          , "I" ((uint8_t)NVMCTRL_CMD_FLWR_gc)
          : "r24", "r25"
        );
      }
      else {
        if (ch == 'E') {
          /* Supports EEPROM writing. */
          /* You can pass the file with
            'avrdude -U eeprom:w:Sketch.eep:a' option. */
          address.word += MAPPED_EEPROM_START;
          nvm_cmd(NVMCTRL_CMD_EEERWR_gc);
        }
        else {
          /* Supports BOOTROW/USERROW writing. */
          /* You can pass the file with
            'avrdude -U userrow:w:data.hex:a' option. */
          nvm_cmd(NVMCTRL_CMD_FLPER_gc);
          *(address.bptr) = 0;
          nvm_cmd(NVMCTRL_CMD_FLWR_gc);
        }
        __asm__ __volatile__ (
          R"#ASM#(
          1:  LD    R0, X+  ; R0 <- X+
              ST    Z+, R0  ;
              SBIW  %0, 1   ; Decrement
              BRNE  1b      ; Branch if Not Equal
          )#ASM#"
          :
          : "r" (length.word)
          , "z" (address.bptr)  /* Z <- to eeprom.ptr */
          , "x" (buff.bptr)     /* X <- from sram.ptr */
        );
      }
      end_of_packet();
    }
    else if (ch == STK_READ_PAGE) {
      /* Read memory block mode, length is big endian. */
      length.bytes[1] = pullch();
      length.bytes[0] = pullch();
      ch = pullch();
      end_of_packet();

      /* the entire flash does not fit in the same address space
         so we call that helper function. */
      if (ch == 'F') {
        /* Read the code space using ELPM. */
        __asm__ __volatile__ (
          R"#ASM#(            ; Z <- address.bptr
          1:  ELPM  R24, Z+   ; R24 <- (RAMPZ:Z)
              RCALL putch     ; putch(R24)
              SBIW  %0, 1     ; Decrement R29:R28
              BRNE  1b        ; Branch if Not Equal
          )#ASM#"
          : "=p" (length.word)
          : "0" (length.word)
          , "z" (address.bptr)
          : "r24", "r25"
        );
      }
      else {
        /* It's not an absolute address, so add the EEPROM offset. */
        if (ch == 'E') address.word += MAPPED_EEPROM_START;
        do putch(*(address.bptr++)); while (--length.word);
      }
    }
    else if (ch == STK_READ_SIGN) {
      /* READ SIGN - return actual device signature from SIGROW
         this enables the same binary to be ued on multiple chips. */
      end_of_packet();

      /* SIGROW_DEVICEID0 : This value is always fixed. */
      putch(0x1E);

      /* This value indicates the flash size and indicates
         whether or not there is a RAMPZ register. */
      putch(SIGROW_DEVICEID1);

      /* Inconsistent values to avoid duplicate SIGROW */
      putch(SIGROW_DEVICEID2);
    }
    else {
      #ifndef RS485_SINGLE
      /* The TxD pin is set to output only after passing here. */
      /* Normally STK_GET_SYNC executes this for the first time. */
      UART_TXPORT.DIR |= UART_TXPIN;
      #endif
      end_of_packet();
    }
    putch(STK_OK);
  } /* Forever loop */
}   /* End of main */

/*** This is a dummy application. It is not included in the output file. ***/

__attribute__((naked))
__attribute__((noreturn))
__attribute__((section( ".appcode")))
void appcode (void) {
  __asm__ __volatile__ ( "RJMP vector_table" );
}

/* end of code */
