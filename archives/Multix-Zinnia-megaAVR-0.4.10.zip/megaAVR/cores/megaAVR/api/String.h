/**
 * @file String.h
 * @author askn (K.Sato) multix.jp
 * @brief Strung subclass
 * @version 0.1
 * @date 2022-09-21
 *
 * @copyright Copyright (c) 2024 askn37 at github.com
 *
 */
// MIT License : https://askn37.github.io/LICENSE.html

#pragma once
#include <avr/pgmspace.h>

#ifdef __cplusplus

class PGM_t;

#if defined(__AVR_TINY__)

#define F(pmem_str) pmem_str
#define P(pmem_ptr) pmem_ptr

#else

#define F(pmem_str) (reinterpret_cast<const PGM_t *>(PSTR(pmem_str)))
#define P(pmem_ptr) (reinterpret_cast<const PGM_t *>(pmem_ptr))

#endif

#endif

// end of code
