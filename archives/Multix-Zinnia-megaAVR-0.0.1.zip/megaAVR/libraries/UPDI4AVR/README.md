# UPDI4AVR (Rev.1)

UPDI (Unified Program and Debug Interface) host firmware over serial\
For AVR DA/DB, megaAVR-0, tinyAVR-2 series from using avrdude, Arduino IDE\
/// High-Voltage programing FUSE fixed supported (hardware support required) ///

> UPDI対応AVR系列のためのシリアル通信ホストファームウェア\
> AVR Dx, megaAVR, tinyAVR系列を対象に avrdude と Arduino IDEで応用可能\
> /// 高電圧プログラミングによる FUSE 書換対応（要ハードウェア支援） ///

## 特徴

- UPDI対応 AVR のための、プログラミングホストファームウェア
  - megaAVR-0系列、tinyAVR-2系列、AVR DA/DB系列用
  - ホスト側、ターゲット側の双方を同系列の UPDI対応デバイスで統一できる
- Arduino IDE および avrdude コマンドラインから使用可能
  - JTAGmkIIプロトコル準拠（JTAG2UPDI 互換）
  - ホスト/ターゲット間は対象系列固有のハードウェアUART伝送
  - ホスト/PC間は 1.5M bps 対応（要 avrdude 7.0、ホスト側F_CPU=16Mhz以上）
  - デバッガ機能なし（不揮発メモリプログラミング＆FUSE書換専用）
  - フラッシュメモリ以外の EEPROM / USERROW 等の特殊領域書換も可能
- 高電圧プログラミング対応（要ハードウェア支援）
  - HV印加は自動制御（avrdude -F オプション付加時）
  - チャージポンプ用PWM逆相ピン出力付
- UARTパススルー対応
  - ライタとして動作しない間はターゲットの UARTが PCと繋げられる

__[ハードウェアとしての UPDI4AVR についてはこちら (Click here)](hardware/README.md)__

## Arduino IDE への導入

1. .ZIPアーカイブをダウンロードする。[Click here](https://github.com/askn37/UPDI4AVR/archive/master.zip)

1. ライブラリマネージャで読み込む

    スケッチ -> ライブラリをインクルード -> .ZIP形式のライブラリをインストール...

1. ツールメニューのボード選択で、UPDIホストにする 適切なターゲットを選ぶ（次節）

1. ファイルメニューのスケッチ例から、UPDI4AVRを選ぶ

    重要！__ビルド可能なボード選択をしていなければ、メニューにこの選択肢は表示されない__

## ライタホストに選択可能なボード種別

このファームウェアは次の要件を満たす AVR にアップロード（インストール）できる。

megaAVR-0 シリーズ、tinyAVR-2 シリーズ、AVR DA/DB シリーズのうち、

- 8KB 以上の FLASH 領域
- 2KB 以上の SRAM 容量
- 2組の ハードウェアUSART サポート

を有していること。

> __リファレンス AVR は ATtiny824 とその上位品種である。__

その他にこのファームウェアは 以下の製品にインストールできる。

[Arduiono / Arduino megaAVR Boards](https://docs.arduino.cc/software/ide-v1/tutorials/getting-started/cores/arduino-megaavr)

- Arduino UNO WiFi Rev 2 (ATmega4809)
- Arduino Nano Every (ATmega4809) -- __推奨しない。（後述）__

[askn37 / Multix Zinnia Product SDK](https://askn37.github.io/) -- megaAVR-0, tinyAVR-0/1/2, AVR DA/DB/DD/EA series support

> デフォルトSDK。HV書込対応。

- megaAVR-0 / tinyAVR-2 / AVR DA/DB
- Microchip Curiosity Nano ATmega4809 (DM320115)
- Microchip Curiosity Nano ATtiny1627 (DM080104)
- Microchip Curiosity Nano AVR128DA48 (DM164151)
- Microchip Curiosity Nano AVR128DB48 (EV35L43A)

> Microchip Curiosity Nano 系列製品中、対象となるのは上記4種。

[MCUdude / MegaCoreX](https://github.com/MCUdude/MegaCoreX) -- megaAVR-0 series support

- megaAVR-0

[SpenceKonde / megaTinyCore](https://github.com/SpenceKonde/megaTinyCore) -- tinyAVR-0,1,2 series support

- tinyAVR-2

[SpenceKonde / DxCore](https://github.com/SpenceKonde/DxCore) -- AVR DA,DB,DD series support

- AVR DA/DB

`Arduino megaAVR Borads` はボードマネージャーから追加インストールする。
その他はそれぞれのサポートサイトの指示に従って、インストールする。

サブメニューで主クロック設定が可能な場合は、
16Mhz、20Mhz、24Mhz (オーバークロック使用時 28Mhz、32Mhz) から選択する。

### 卵と鶏の関係

この UPDI4AVRファームウェアを対象MCUに書き込むには、他のUPDI書込環境が必要である。
つまりまだ何も用意していない状況で、第一選択に UPDI4AVR を選ぶことは出来ない。
従ってまず次の選択をすべきである。

- SerialUPDI 装置を用意/自作する。
  - おそらくもっとも簡単かつ低コスト。
  - 適当なUSB-UARTアダプタと配線材、ブレッドボード、ダイオードが一個あれば作れる。
- オンボード書込器を搭載した既製品を購入/入手する。
  - Microchip Curiosity Nano製品のうち、前述の型番のものなど。
  - 一見簡単そうだがそうでもない。制御信号が衝突するので快適には使えない。
- UPDI書込器完成品を入手する。
  - 色々あることはあるが、HV書込対応品（ましてAVR DD対応）は世界全体を見回しても稀有。

> UPDI難民という言葉すらあるのがこの界隈である。

### Arduino Nano Every について

オンボード搭載プログラムライタチップが JTAG2UPDI over UART 下位互換の特殊品である。
UPDI4AVR を書き込んでも正しい制御が横取りされるために期待した動作をしない。

> オンボードUSB を使わずに追加の UART を JTAG通信用に別途用意し、DTR/RTS信号も配線すれば良いが
ほぼ同じ部材で SerilUPDI 書込器を作れてしまうので、価値がない。

## ターゲットに選択可能なモダンAVR品種

2022年前期時点で発表済の品種のみ記載。実機検証済には __\*__ を付す。

|ファミリ|2KB|4KB|8KB|16KB|32KB|主な外観|
|---------|----------|----------|----------|-----------|-----------|-------------|
|tinyAVR-0|ATtiny202*|ATtiny402 |          |           |           |SOP8         |
|         |ATtiny204 |ATtiny404 |ATtiny804 |ATtiny1604 |           |SOP14        |
|         |          |ATTiny406 |ATtiny806 |ATtiny1606 |           |VQFN20 SOP20 |
|         |          |          |ATTiny807 |ATtiny1607 |           |VQFN24       |
|tinyAVR-1|ATtiny212 |ATtiny412*|          |           |           |SOP8         |
|         |ATtiny214 |ATtiny414 |ATtiny814*|ATtiny1614*|           |SOP14        |
|         |          |ATtiny416 |ATtiny816 |ATtiny1616*|ATtiny3216*|VQFN20 SOP20 |
|         |          |ATtiny417 |ATtiny817 |ATtiny1617 |ATTiny3217 |VQFN24       |
|tinyAVR-2|          |ATtiny424 |ATtiny824*|ATtiny1624 |ATtiny3224 |SOP14 TSSOP14|
|         |          |ATtiny426 |ATtiny826 |ATtiny1626 |ATtiny3226 |VQFN20 SOP20 |
|         |          |ATtiny427 |ATtiny827 |ATtiny1627 |ATTiny3227 |VQFN24       |
||8KB|16KB|32KB|48KB|||
|megaAVR-0|ATmega808 |ATmega1608|ATmega3208|ATmega4808*|           |TSOP28 TQFP32|
|         |ATmega809 |ATmega1609|ATmega3209|ATmega4809*|           |DIP40 TQFP48 |
|||16KB|32KB|64kB|128KB||
|AVR DA   |          |          |AVR32DA28 |AVR64DA28  |AVR128DA28 |DIP28 TSOP28 |
|         |          |          |AVR32DA32*|AVR64DA32  |AVR128DA32 |TQFP32 VQFN32|
|         |          |          |AVR32DA48 |AVR64DA48  |AVR128DA48 |TQFP48 VQFN48|
|         |          |          |          |AVR64DA64  |AVR128DA64 |VQFN64       |
|AVR DB   |          |          |AVR32DB28 |AVR64DB28  |AVR128DB28 |DIP28 TSOP28 |
|         |          |          |AVR32DB32 |AVR64DB32  |AVR128DB32*|TQFP32 VQFN32|
|         |          |          |AVR32DB48 |AVR64DB48  |AVR128DB48*|TQFP48 VQFN48|
|         |          |          |          |AVR64DB64  |AVR128DB64 |VQFN64       |
|AVR DD   |          |AVR16DD14 |AVR32DD14*|AVR64DD14  |           |SOP14 TSSOP14|
|         |          |AVR16DD20 |AVR32DD20 |AVR64DD20  |           |VQFN20 SOP20 |
|         |          |AVR16DD28 |AVR32DD28 |AVR64DD28  |           |DIP28 TSOP28 |
|         |          |AVR16DD32 |AVR32DD32 |AVR64DD32* |           |TQFP32 VQFN32|

> 2022時点では、UPDI対応品種で USB-IFが搭載されたものは用意されていない。\
> 似たような型番だが以下の品種は本表のUPDI系ファミリに該当しない PDI/TPI系の別系統別品種。\
Attiny102/104 ATtiny828/1628/3228

## 基本的な使い方

もっとも簡単な ターゲット 〜 UPDI4AVR 間配線は、VCC、GND、UPDI の3本を配線するだけ。

```plain

Target AVR     UPDI4AVR      Host PC
  +------+     +------+     +------+
  |  UPDI|<--->|PROG  |     |      |
  |      |     |    TX|---->|RX    |
  |   VCC|<----|VCC   |     |      |
  |      |     |    RX|<----|TX    |
  |   GND|---->|GND   |     |      |
  +------+     +------+     +------+

Fig.1 Programing Bridge Wireing
```

UPDI4AVR の UPDIプログラムピンは、品種（およびコンパイルオプション）によって異なる。以下は一例。

|HOST|PIN|PORT|
|----|---|----|
|Arduino UNO WiFi Rev.2|D6|PF4|
|Curiosity Nano AVR128|--|PC0|
|ATtiny824|--|PB2|

その他のピン接続は
[設定ファイル](examples/UPDI4AVR/configuration.h)、
[詳細な使い方](document/advanced.md)
を参照のこと

Arduino IDE ツールメニューでは 書込装置に __JTAG2UPDI__ を指定する。

- 現行の Arduino IDE 1.8.x 同梱の *avrdude* は古いため、
最高通信速度は 115200 bps に制限される。

ターゲット品種を適切に指定し、ブートローダーの書込に成功すれば正常に動作している。\
実際に書込を試みる前に、正常接続性を確認するには [avrdude操作例](document/Avrdude.md) を参照のこと。

## 注意

- AS IS（無保証、無サポート、使用は自己責任で）
- UNO WiFi、Nano Every などは PCとの
UART通信開始時の自動リセットを無効化することができない。
このため UPDI4AVR 通信開始時に自分自身のリセットを含む、数秒以上の無応答遅延時間がある。
  - オンボードデバッガによって直接リセットされるため、外付部品追加での回避はできない。
  - より高度な機能を活用するにはベアチップと専用の回路とで構築するほうが好ましい。
- Arduino IDE からは高電圧プログラミング、デバイス施錠、デバイス解錠、
EEPROM書換などの高度な指示をすることは原則出来ない。
これらはコマンドラインから *avrdude* を操作することで対応する。
  - [Multix Zinnia Product SDK](https://askn37.github.io/) はサブメニューで対応。
- デバッガインタフェースとしては機能しない。特殊領域書換とチップ消去にのみ対応。
  - UPDIオンボードデバッグ制御プロトコルは非公開のプロプライエタリ。
- 高電圧プログラミングには、追加のハードウェア支援が絶対に必要。（必然的に）

## うまく動かない場合

- メニュー設定を確認する
  - AVR のボードマネージャー種別
    - megaAVR-0、tinyAVR-2、AVR DA/DB の各系統以外ではビルドできない
    - ATmega328P 等の旧世代 AVR は使用不能
  - AVR のサブ品種選択
  - シリアルポートの選択
  - 書込装置の選択
- 配線を確認する
  - 電源供給はホスト側かターゲット側のどちらか一方からのみ供給する（電圧を揃える）
  - ファームウェアを書く時、FUSEを書く時は ターゲットの UART線は外す
    - UARTパススルーを併用しない
  - なるべく短い線材を使う
- 復旧に高電圧プログラミングが必要になる FUSE設定を安易に試さない
  - そういう FUSE をくれぐれも間違って書かない

## 課題

- USARTを2系統使うため少ピン品種で選べる形式が限られる。（tinyAVR-2のみ）
  - CCL/LUTや PORTMUXを駆使すれば1系統消費で済み対応品種を増やせるかも。
  - むしろそうしないと AVR DD 少ピン品種で対応できない。（販売開始が遅かったので考慮しなかった）
- DTR/RTS信号線を活用していない。
  - 元々Arduino互換機設計あわせだったのでリセット検出にしか使えていない。
  - レベル検出可能なハード設計に特化すれば avrdudeとの連携を深められるはず。

## その他の情報

- [avrdude操作例](document/avrdude.md)
- [詳細な使い方・高電圧プログラミング](document/advanced.md)

## 著作表示

Twitter: [@askn37](https://twitter.com/askn37) \
GitHub: [https://github.com/askn37/](https://github.com/askn37/) \
Product: [https://askn37.github.io/](https://askn37.github.io/)

Copyright (c) askn (K.Sato) multix.jp \
Released under the MIT license \
[https://opensource.org/licenses/mit-license.php](https://opensource.org/licenses/mit-license.php) \
[https://www.oshwa.org/](https://www.oshwa.org/)
