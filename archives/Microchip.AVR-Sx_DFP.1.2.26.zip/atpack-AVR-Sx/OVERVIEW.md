# Overview

The Microchip AVR-Sx Series Device Family Pack (DFP) is a [CMSIS-Pack](https://open-cmsis-pack.github.io/Open-CMSIS-Pack-Spec/main/html/index.html) that:

- Enables compatible tools with device support.
- Contains support files for the [MPLAB XC8 Compiler](https://www.microchip.com/en-us/tools-resources/develop/mplab-xc-compilers/xc8).

## Support

For support questions, contact Microchip Support through [https://www.microchip.com/en-us/support](https://www.microchip.com/en-us/support).
