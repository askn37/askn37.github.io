#!/usr/bin/env bash -e -

# AVRDUDEROOT=~/Library/Arduino15/packages/MultiX-Zinnia/tools/avrdude/8.2-avrdude/bin
AVRDUDEROOT=../../../../../tools/avrdude/8.2-avrdude/bin
PORT=/dev/cu.usbserial-230
PGM=jtag2updi
PART=m4809
BOOTS=./boot_atmega4809.hex

# The BOOTCODE granularity for this series is 256 bytes, so write 2 to FUSE8.

${AVRDUDEROOT}/avrdude -P $PORT -c $PGM -p $PART \
  -U syscfg0:w:0xd9:m \
  -U bootsize:w:2:m \
  -U flash:w:$BOOTS:i
