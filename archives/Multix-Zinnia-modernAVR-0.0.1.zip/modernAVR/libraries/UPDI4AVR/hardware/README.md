# UPDI4AVR hardware project

## 特徴

- UPDI方式AVR（モダンAVR）のための、プログラミングライタハードウェア
  - 対応ターゲットは megaAVR系列、tinyAVR系列、AVR Dx系列
  - ホスト制御には ATtiny824 (またはその同等品) を採用
- Arduino IDE および avrdude コマンドラインから使用可能
  - JTAGmkIIプロトコル準拠（JTAG2UPDI 互換）
  - ホスト/ターゲット間は対象系列固有のハードウェアUART伝送
  - ホスト/PC間は 1.5M bps 対応（要 avrdude 7.0、ホスト側F_CPU=16Mhz以上）
  - デバッガ機能なし（不揮発メモリプログラミング＆FUSE書換専用）
- 高電圧プログラミング支援
  - HV印加は自動制御（avrdude -F オプション付加時）
  - 12V系列と 9V系列はジャンパプラグで切替対応
- UARTパススルー対応（ライタとして動作しない間はターゲットのUARTがPCと繋げられる）

__[ファームウェアとしての UPDI4AVR についてはこちら (Click here)](../README.md)__
