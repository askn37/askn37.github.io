# TPI4AVR

TPI (Tiny Programing Interface) host firmware over serial\
For ATtiny4/5/9/10 series from using avrdude, Arduino IDE\
/// High-Voltage programing FUSE fixed supported (experimental : hardware support required) ///

> TPI対応ATtiny系列のためのシリアル通信ホストファームウェア\
> ATtiny4/5/7/10系列を対象に avrdude と Arduino IDEで応用可能\
> /// 高電圧プログラミングによる FUSE 書換対応（実験的：要ハードウェア支援） ///

## 特徴

- TPI方式AVRのための、プログラミングホストファームウェア
  - ターゲット側は ATtiny4/5/9/10 系列専用
  - ホスト側は megaAVR-0系列、tinyAVR-2系列、AVR Dx系列専用
- Arduino IDE および avrdude コマンドラインから使用可能
  - JTAGmkIIプロトコル準拠（JTAG2UPDI に同等）
  - ホスト/ターゲット間は、対象系列チップ固有のハードウェアUART支援による高速伝送
  - ホスト/PC間は最大 3M bps 対応（要 avrdude 7.0、ホスト側F_CPU=24Mhz以上）
  - デバッガ機能なし（メモリプログラミング＆FUSE書換専用）
- 高電圧プログラミングに実験的対応（要ハードウェア支援）

## Arduino IDE への導入

1. .ZIPアーカイブをダウンロードする。[Click here](https://github.com/askn37/TPI4AVR/archive/master.zip)

1. ライブラリマネージャで読み込む

    スケッチ -> ライブラリをインクルード -> .ZIP形式のライブラリをインストール...

1. ツールメニューのボード選択で、UPDIホストにする 適切なターゲットを選ぶ

1. ファイルメニューのスケッチ例から、TPI4AVRを選ぶ

    重要！__ビルド可能なボードを選択をしていなければ、メニューにこの選択肢は表示されない__

## ライタホストに選択可能なボード種別例

TPI4AVRは、MCUに megaAVR-2系列または AVR Dx系列を採用し、
SRAM 2KB以上（≒FLASH 16KB以上）の品種にインストールできる。

- Arduino megaAVR Borads
  - Arduino UNO WiFi Rev.2
  - Arduino Nano Every
- DxCore
  - (select sub model...)
- MegaCoreX
  - (select sub model...)
- megaTinyCore *
  - (select sub model...)
- MULTIX.JP Zinnia Duino Borads
  - (select sub model...)

`Arduino megaAVR Borads` はボードマネージャーから追加インストールする。
その他はそれぞれのサポートサイトの指示に従って、インストールする。

サブメニューで主クロック設定が可能な場合は、
16Mhz、20Mhz、24Mhz から選択する。

この TPI4AVR を用いてこれから初めて TPI 対応開発環境を整えるのであれば、
まず Aruduino Nano Every を入手してライタホスト器に仕立てるのが良い。

\* tinyAVR-2 シリーズの 8KB以上品種にもインストール可能。（DEBUGコンソール使用不可）

## TPIターゲットに選択可能なAVR品種

## 基本的な使い方

## Arudiuino IDE 上への TPI開発環境構築

## 注意

- AS IS（無保証、無サポート、使用は自己責任で）

## うまく動かない場合

- メニュー設定を確認する
  - AVR のボードマネージャー種別
  - AVR のサブ品種選択
  - シリアルポートの選択
  - 書込装置の選択
- 配線を確認する
  - 電源供給はホスト側かターゲット側のどちらか一方からのみ供給する（電圧を揃える）
  - あまり長い線材は使わない（最長でも300mm以内）
- 高電圧プログラミングは、安易に試さない
  - そういう FUSE を書かない

megaAVR-0、tinyAVR-2、AVR Dx の各系統以外では TPI4AVR はビルドできない。ATmega328P等は不可。

## 付記：そもそもの開発経緯

## 関連リンク

- [MCUdude / MegaCoreX](https://github.com/MCUdude/MegaCoreX) -- megaAVR-0 series support
- [SpenceKonde / megaTinyCore](https://github.com/SpenceKonde/megaTinyCore) -- tinyAVR-0,1,2 series support
- [SpenceKonde / DxCore](https://github.com/SpenceKonde/DxCore) -- AVR DA,DB,DD series support
- [askn37 / MULTIX.JP Zinnia Duino Boards](https://github.com/askn37/Zinnia-Duino) -- in preparation（準備中）

## 既知の不具合／制約／課題

- 英文マニュアルが未整備である。（努力目標）

## 改版履歴

- 0.1 初版

## 使用許諾

- MIT
  - 本成果物には含まれないが、使用例で触れる optiboot は GPL v2 である。

## 著作表示

朝日薫 / askn

- Twitter: [@askn37](https://twitter.com/askn37)
- GitHub: [https://github.com/askn37](https://github.com/askn37)
